import React, { useEffect, useState } from "react";
import {
  ActivityIndicator, Alert, SafeAreaView, ScrollView, StatusBar,
  StyleSheet, Text, TextInput, TouchableOpacity, View
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { VideoView, useVideoPlayer } from "expo-video";

const API_BASE_URL = "http://YOUR_COMPUTER_LAN_IP:4000";

type Clip = { uri: string; name: string; durationMs: number } | null;

function VideoPreview({ uri }: { uri: string | null }) {
  const player = useVideoPlayer(uri, p => { p.loop = true; });
  if (!uri) {
    return <View style={styles.emptyPreview}><Text style={styles.playIcon}>▶</Text><Text style={styles.muted}>Choose a video to start editing</Text></View>;
  }
  return <VideoView player={player} style={styles.preview} nativeControls contentFit="contain" />;
}

export default function App() {
  const [clip, setClip] = useState<Clip>(null);
  const [start, setStart] = useState("0");
  const [end, setEnd] = useState("");
  const [resolution, setResolution] = useState<"1080" | "4k">("1080");
  const [busy, setBusy] = useState(false);
  const [progressText, setProgressText] = useState("");
  const [exportUrl, setExportUrl] = useState("");

  async function chooseVideo() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission needed", "Allow access to choose a video.");
      return;
    }
    const picked = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["videos"], allowsEditing: false, videoMaxDuration: 600
    });
    if (picked.canceled || !picked.assets[0]) return;
    const asset = picked.assets[0];
    const durationMs = asset.duration || 0;
    setClip({ uri: asset.uri, name: asset.fileName || "my-video.mp4", durationMs });
    setStart("0");
    setEnd(durationMs ? String((durationMs / 1000).toFixed(1)) : "");
    setExportUrl("");
  }

  async function exportVideo() {
    if (!clip) {
      Alert.alert("No video selected", "Choose a video before exporting.");
      return;
    }
    const startSeconds = Number(start);
    const endSeconds = Number(end);
    if (!Number.isFinite(startSeconds) || !Number.isFinite(endSeconds) || startSeconds < 0 || endSeconds <= startSeconds) {
      Alert.alert("Check trim values", "End time must be greater than start time, and both must be valid seconds.");
      return;
    }
    if (clip.durationMs && endSeconds > clip.durationMs / 1000 + 0.5) {
      Alert.alert("End time is too long", "Set the end time within the selected video's duration.");
      return;
    }

    setBusy(true);
    setProgressText("Uploading video...");
    setExportUrl("");
    try {
      const form = new FormData();
      form.append("video", {
        uri: clip.uri,
        name: clip.name.toLowerCase().endsWith(".mp4") ? clip.name : "source-video.mp4",
        type: "video/mp4"
      } as any);
      form.append("start", String(startSeconds));
      form.append("end", String(endSeconds));
      form.append("resolution", resolution);

      const response = await fetch(`${API_BASE_URL}/api/export`, {
        method: "POST",
        body: form
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Export failed");
      const url = `${API_BASE_URL}${data.url}`;
      setExportUrl(url);
      setProgressText("Export complete!");
    } catch (error: any) {
      setProgressText("");
      Alert.alert("Export failed", error?.message || "Check your backend URL and connection.");
    } finally {
      setBusy(false);
    }
  }

  async function saveOrShare() {
    if (!exportUrl) return;
    try {
      const target = `${FileSystem.cacheDirectory}editrix-export-${Date.now()}.mp4`;
      const downloaded = await FileSystem.downloadAsync(exportUrl, target);
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(downloaded.uri, { mimeType: "video/mp4", dialogTitle: "Save or share your EDITRIX video" });
      } else {
        Alert.alert("Export downloaded", `Video saved temporarily at ${downloaded.uri}`);
      }
    } catch (error: any) {
      Alert.alert("Download failed", error?.message || "Could not download the exported video.");
    }
  }

  const duration = clip?.durationMs ? (clip.durationMs / 1000).toFixed(1) : "Unknown";

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#F4F8FF" />
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <View style={styles.logo}><Text style={styles.logoText}>E</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.brand}>EDITRIX <Text style={styles.brandBlue}>AI</Text></Text>
            <Text style={styles.subtitle}>Professional video editor</Text>
          </View>
          <Text style={styles.studio}>STUDIO</Text>
        </View>

        <View style={styles.hero}>
          <Text style={styles.eyebrow}>CREATE • EDIT • EXPORT</Text>
          <Text style={styles.heroTitle}>Your story.{"\n"}Your timeline.</Text>
          <Text style={styles.heroSub}>Trim a clip and export an MP4 in HD or 4K.</Text>
        </View>

        <TouchableOpacity style={styles.chooseButton} onPress={chooseVideo}>
          <Text style={styles.chooseIcon}>＋</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.chooseTitle}>{clip ? "Change video" : "Choose a video"}</Text>
            <Text style={styles.chooseSub}>Select an MP4 or supported video from your device</Text>
          </View>
          <Text style={styles.chevron}>›</Text>
        </TouchableOpacity>

        <View style={styles.panel}>
          <View style={styles.panelHeading}><Text style={styles.panelTitle}>Preview</Text><Text style={styles.meta}>{clip ? `${duration}s` : "NO CLIP"}</Text></View>
          <VideoPreview uri={clip?.uri || null} />
          {clip && <Text style={styles.filename} numberOfLines={1}>{clip.name}</Text>}
        </View>

        <View style={styles.panel}>
          <View style={styles.panelHeading}><Text style={styles.panelTitle}>Timeline · Clip 01</Text><Text style={styles.meta}>TRIM</Text></View>
          <View style={styles.timelineTrack}>
            <View style={styles.timelineFill}><Text style={styles.timelineText}>▶  VIDEO CLIP</Text></View>
          </View>
          <Text style={styles.fieldLabel}>Start time (seconds)</Text>
          <TextInput style={styles.input} keyboardType="decimal-pad" value={start} onChangeText={setStart} placeholder="0" />
          <Text style={styles.fieldLabel}>End time (seconds)</Text>
          <TextInput style={styles.input} keyboardType="decimal-pad" value={end} onChangeText={setEnd} placeholder="Enter end time" />
          <Text style={styles.tip}>Tip: set 2 and 12 to export the section from 2s to 12s.</Text>
        </View>

        <View style={styles.panel}>
          <Text style={styles.panelTitle}>Export resolution</Text>
          <View style={styles.resolutionRow}>
            <TouchableOpacity onPress={() => setResolution("1080")} style={[styles.resolution, resolution === "1080" && styles.resolutionActive]}>
              <Text style={[styles.resolutionText, resolution === "1080" && styles.resolutionTextActive]}>1080p HD</Text>
              <Text style={styles.resolutionSub}>1920 px max</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setResolution("4k")} style={[styles.resolution, resolution === "4k" && styles.resolutionActive]}>
              <Text style={[styles.resolutionText, resolution === "4k" && styles.resolutionTextActive]}>4K UHD</Text>
              <Text style={styles.resolutionSub}>3840 px max</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.tip}>4K export cannot add detail that was not present in the original video.</Text>
        </View>

        <TouchableOpacity disabled={busy} style={[styles.exportButton, busy && { opacity: 0.6 }]} onPress={exportVideo}>
          {busy ? <ActivityIndicator color="white" /> : <Text style={styles.exportIcon}>⇧</Text>}
          <Text style={styles.exportText}>{busy ? "Processing..." : "Export video"}</Text>
        </TouchableOpacity>
        {!!progressText && <Text style={styles.status}>{progressText}</Text>}
        {!!exportUrl && <TouchableOpacity style={styles.shareButton} onPress={saveOrShare}><Text style={styles.shareText}>↓  Download / Share exported video</Text></TouchableOpacity>}

        <View style={styles.comingSoon}>
          <Text style={styles.comingTitle}>Next editing tools</Text>
          <Text style={styles.comingText}>Multi-clip timeline • Music tracks • Text overlays • Transitions • Filters • AI captions</Text>
        </View>
        <Text style={styles.footer}>EDITRIX AI · Made for creators</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F4F8FF" }, container: { padding: 18, paddingBottom: 40 },
  header: { flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 22 },
  logo: { width: 45, height: 45, borderRadius: 14, backgroundColor: "#1769E0", alignItems: "center", justifyContent: "center" },
  logoText: { color: "white", fontWeight: "900", fontSize: 26 },
  brand: { color: "#102B4C", fontSize: 20, fontWeight: "900", letterSpacing: 1 },
  brandBlue: { color: "#1769E0" }, subtitle: { color: "#7B8DA4", fontSize: 11, marginTop: 2 },
  studio: { color: "#1769E0", backgroundColor: "#E4EFFF", paddingHorizontal: 11, paddingVertical: 7, borderRadius: 20, fontSize: 10, fontWeight: "900" },
  hero: { backgroundColor: "#E5F0FF", padding: 21, borderRadius: 22, marginBottom: 17 },
  eyebrow: { color: "#1769E0", fontSize: 10, fontWeight: "900", letterSpacing: 1.5, marginBottom: 9 },
  heroTitle: { color: "#102B4C", fontSize: 30, lineHeight: 35, fontWeight: "900" },
  heroSub: { color: "#637A96", fontSize: 12, marginTop: 9 },
  chooseButton: { flexDirection: "row", alignItems: "center", gap: 12, padding: 15, backgroundColor: "#1769E0", borderRadius: 17, marginBottom: 15 },
  chooseIcon: { color: "white", fontSize: 27, fontWeight: "300" }, chooseTitle: { color: "white", fontSize: 14, fontWeight: "900" },
  chooseSub: { color: "#DCEAFF", fontSize: 10, marginTop: 3 }, chevron: { color: "white", fontSize: 25 },
  panel: { backgroundColor: "white", borderRadius: 19, borderWidth: 1, borderColor: "#E1EAF5", padding: 15, marginBottom: 14 },
  panelHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  panelTitle: { color: "#173452", fontWeight: "900", fontSize: 15 },
  meta: { color: "#1769E0", fontSize: 10, fontWeight: "900" },
  emptyPreview: { height: 185, backgroundColor: "#F1F6FD", borderRadius: 13, alignItems: "center", justifyContent: "center" },
  playIcon: { color: "#1769E0", fontSize: 31, marginBottom: 7 }, muted: { color: "#8797AA", fontSize: 12 },
  preview: { width: "100%", height: 220, backgroundColor: "#0D1B2A", borderRadius: 13 },
  filename: { color: "#647B96", fontSize: 11, marginTop: 8 },
  timelineTrack: { height: 44, backgroundColor: "#EDF4FF", borderRadius: 10, padding: 4, marginBottom: 14 },
  timelineFill: { flex: 1, backgroundColor: "#C9DEFF", borderRadius: 7, justifyContent: "center", paddingHorizontal: 12 },
  timelineText: { color: "#1556A8", fontSize: 11, fontWeight: "900" },
  fieldLabel: { color: "#536B86", fontSize: 11, fontWeight: "800", marginBottom: 6, marginTop: 5 },
  input: { borderWidth: 1, borderColor: "#DCE7F5", borderRadius: 11, paddingHorizontal: 12, paddingVertical: 10, color: "#173452", backgroundColor: "#FBFDFF" },
  tip: { color: "#8999AC", fontSize: 10, lineHeight: 15, marginTop: 9 },
  resolutionRow: { flexDirection: "row", gap: 10, marginTop: 12 },
  resolution: { flex: 1, borderWidth: 1, borderColor: "#DFE8F4", borderRadius: 13, padding: 13, backgroundColor: "#FBFDFF" },
  resolutionActive: { borderColor: "#1769E0", backgroundColor: "#EDF5FF" },
  resolutionText: { color: "#38536F", fontWeight: "900", fontSize: 13 },
  resolutionTextActive: { color: "#1769E0" }, resolutionSub: { color: "#8999AC", fontSize: 10, marginTop: 4 },
  exportButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, backgroundColor: "#1769E0", borderRadius: 15, padding: 16, marginTop: 3 },
  exportIcon: { color: "white", fontSize: 20 }, exportText: { color: "white", fontSize: 15, fontWeight: "900" },
  status: { color: "#1769E0", textAlign: "center", fontSize: 12, marginTop: 10 },
  shareButton: { backgroundColor: "#E5F0FF", borderRadius: 13, padding: 14, marginTop: 10 },
  shareText: { color: "#1769E0", textAlign: "center", fontWeight: "900", fontSize: 12 },
  comingSoon: { backgroundColor: "#EAF3FF", borderRadius: 15, padding: 15, marginTop: 17 },
  comingTitle: { color: "#1769E0", fontWeight: "900", marginBottom: 5 },
  comingText: { color: "#637A96", fontSize: 11, lineHeight: 17 },
  footer: { textAlign: "center", color: "#9AA9BA", fontSize: 10, marginTop: 22 }
});
