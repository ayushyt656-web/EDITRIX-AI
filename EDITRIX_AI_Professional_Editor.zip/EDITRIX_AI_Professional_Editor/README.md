# EDITRIX AI — Professional Video Editor MVP

This upgrade adds a working **single-video trim and MP4 export** workflow to the Expo mobile app.

## What works
- Select one video from the phone library.
- Preview it in the app.
- Set trim start and end times in seconds.
- Export a trimmed MP4 using FFmpeg on a backend computer/server.
- Choose 1080p HD or 4K UHD maximum output dimension.
- Download/share the exported MP4 from the phone.

## What this is not yet
This is not a full multi-track nonlinear editor. Multiple clips, draggable timeline handles, audio/music tracks, transitions, text overlays, filters, AI captions burned into video, and native on-device rendering are not implemented in this MVP. The 4K option scales to a maximum 3840-pixel long edge; it cannot create detail absent from a lower-resolution original. Actual 4K export requires a capable backend machine and can take significant time and storage.

## Requirements
- Computer or server with Node.js 20+ and FFmpeg installed and available as `ffmpeg` on PATH.
- Phone and computer on the same Wi-Fi for local testing.
- Expo Go for a development preview.
- For production, deploy the backend over HTTPS, add authentication, private per-user storage, rate limits, cleanup jobs, and upload quotas.

FFmpeg download: https://ffmpeg.org/download.html

## Step 1 — Install mobile dependencies
In this project folder:

```bash
npm install
npx expo install expo-image-picker expo-video expo-file-system expo-sharing
```

## Step 2 — Install backend dependencies
Open a second terminal:

```bash
cd backend
npm install
```

Install FFmpeg separately and verify:

```bash
ffmpeg -version
```

Start the server:

```bash
npm start
```

Health check: open `http://localhost:4000/api/health` on the computer. You should see JSON with `"ok": true`.

## Step 3 — Connect your phone
Find your computer's local Wi-Fi IP address. Edit the `API_BASE_URL` constant at the top of `App.tsx`:

```ts
const API_BASE_URL = "http://192.168.1.20:4000";
```

Replace the sample address with your actual LAN IP. The phone and computer must be on the same Wi-Fi. Allow port 4000 through your computer firewall for private/local network use only.

For iOS, local HTTP networking may be restricted by platform settings. Prefer an HTTPS backend for reliable device testing and all production use. Never expose an unauthenticated development export server to the public internet.

## Step 4 — Run the app
From the project root:

```bash
npx expo start
```

Scan the QR code with Expo Go.

## Step 5 — Use the editor
1. Tap Choose a video.
2. Preview the selected clip.
3. Enter a start time and end time in seconds.
4. Choose 1080p HD or 4K UHD.
5. Tap Export video.
6. When complete, tap Download / Share exported video.

The server accepts one video upload up to 500 MB and exports clips up to 10 minutes. The uploaded source file is deleted after processing. Exported files remain in `backend/work`; delete them periodically or add an automatic cleanup policy before real-world deployment.

## Build Android and iOS packages
Follow the current Expo EAS Build guide:
https://docs.expo.dev/build/introduction/

```bash
npx eas-cli@latest build:configure
```

Then follow EAS instructions to build Android and iOS. iOS distribution generally requires an Apple Developer account.

## Important production security
This sample backend is for local development. Before public release:
- Add user authentication and authorization.
- Store files in private object storage and use expiring download links.
- Add per-user quotas, request limits, and abuse protection.
- Validate media by probing actual file contents, not only MIME type.
- Run FFmpeg in an isolated worker/container with CPU, memory, duration and disk limits.
- Add automatic deletion/retention controls and a privacy policy.
- Use HTTPS; do not publish the local development server as-is.

## FFmpeg export behavior
The backend trims using `-ss` and `-t`, encodes H.264 video and AAC audio, and uses a scale filter that preserves aspect ratio. The selected resolution is a maximum long-edge size (1920 or 3840). Output is MP4 with fast-start metadata for easier playback.
