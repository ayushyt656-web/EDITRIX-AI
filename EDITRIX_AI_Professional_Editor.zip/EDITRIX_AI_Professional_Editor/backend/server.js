import express from "express";
import cors from "cors";
import multer from "multer";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const workDir = path.join(__dirname, "work");
fs.mkdirSync(workDir, { recursive: true });

const app = express();
app.use(cors());
app.use("/exports", express.static(workDir, { dotfiles: "deny", index: false }));
const upload = multer({
  dest: workDir,
  limits: { fileSize: 500 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith("video/")) cb(null, true);
    else cb(new Error("Please upload a video file."));
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "EDITRIX video export" }));

app.post("/api/export", upload.single("video"), async (req, res) => {
  const input = req.file?.path;
  if (!input) return res.status(400).json({ error: "Choose a video to export." });

  const start = Number(req.body.start);
  const end = Number(req.body.end);
  const resolution = req.body.resolution === "4k" ? "4k" : "1080";
  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end <= start || end - start > 600) {
    fs.unlink(input, () => {});
    return res.status(400).json({ error: "Invalid trim range. Maximum export length is 10 minutes." });
  }

  const id = randomUUID();
  const outputName = `${id}.mp4`;
  const output = path.join(workDir, outputName);
  const maxSize = resolution === "4k" ? 3840 : 1920;

  // Scale up or down while preserving aspect ratio. This does not invent source detail.
  const filter = `scale='if(gte(iw,ih),min(iw,${maxSize}),-2)':'if(gte(iw,ih),-2,min(ih,${maxSize}))':force_original_aspect_ratio=decrease`;

  const args = [
    "-hide_banner", "-y",
    "-ss", String(start),
    "-i", input,
    "-t", String(end - start),
    "-vf", filter,
    "-c:v", "libx264",
    "-preset", "veryfast",
    "-crf", "20",
    "-pix_fmt", "yuv420p",
    "-c:a", "aac",
    "-b:a", "192k",
    "-movflags", "+faststart",
    output
  ];

  const ffmpeg = spawn("ffmpeg", args);
  let stderr = "";
  ffmpeg.stderr.on("data", chunk => { stderr += chunk.toString(); if (stderr.length > 12000) stderr = stderr.slice(-12000); });
  ffmpeg.on("error", err => {
    fs.unlink(input, () => {});
    res.status(500).json({ error: "FFmpeg could not start. Install FFmpeg and make sure it is on PATH." });
  });
  ffmpeg.on("close", code => {
    fs.unlink(input, () => {});
    if (code !== 0) {
      fs.unlink(output, () => {});
      console.error("FFmpeg error:", stderr);
      if (!res.headersSent) res.status(500).json({ error: "Video processing failed. Check that FFmpeg is installed and the source video is supported." });
      return;
    }
    res.json({ ok: true, url: `/exports/${outputName}`, resolution });
  });
});

app.use((err, _req, res, _next) => {
  console.error(err?.message || err);
  if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({ error: "Video is larger than the 500 MB upload limit." });
  }
  res.status(400).json({ error: err?.message || "Upload error." });
});

const port = process.env.PORT || 4000;
app.listen(port, "0.0.0.0", () => console.log(`EDITRIX export server running on port ${port}`));
